package com.cookandroid.mynavermovie

data class MovieItem (val title:String, val score1:String, val score2:String, val reserve:String, var imgsrc:String)