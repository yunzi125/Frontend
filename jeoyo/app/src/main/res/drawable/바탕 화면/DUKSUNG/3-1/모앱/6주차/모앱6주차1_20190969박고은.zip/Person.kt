package com.cookandroid.myaddress

data class Person (val name:String?, val mobile:String?)