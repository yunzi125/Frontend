package com.cookandroid.myreservation

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.*

class MainActivity : AppCompatActivity() {
    lateinit var chrono : Chronometer
    lateinit var btnStart : Button
    lateinit var btnEnd : Button
    lateinit var rdoCal : RadioButton
    lateinit var rdoTime :  RadioButton
    lateinit var calView : CalendarView
    lateinit var tPicker : TimePicker
    lateinit var tvYear : TextView
    lateinit var tvMonth : TextView
    lateinit var tvDay : TextView
    lateinit var tvHour : TextView
    lateinit var tvMinute : TextView

    var selectYear : Int = 0
    var selectMonth : Int = 0
    var selectDay : Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnStart=findViewById(R.id.btnStart)
        btnEnd = findViewById(R.id.btnEnd)
        chrono = findViewById(R.id.chronometer1)
        rdoCal = findViewById(R.id.rdoCal)
        rdoTime = findViewById(R.id.rdoTime)
        tPicker = findViewById(R.id.timePicker1)
        calView=findViewById(R.id.calendarView1)
        tvYear = findViewById(R.id.tvYear)
        tvMonth=findViewById(R.id.tvMonth)
        tvDay=findViewById(R.id.tvDay)
        tvHour=findViewById(R.id.tvHour)
        tvMinute=findViewById(R.id.tvMinute)

        tPicker.visibility=android.view.View.INVISIBLE
        calView.visibility = View.INVISIBLE
        rdoCal.setOnClickListener {
            calView.visibility = View.VISIBLE
            tPicker.visibility = View.INVISIBLE
        }
        rdoTime.setOnClickListener{
            calView.visibility = View.INVISIBLE
            tPicker.visibility = View.VISIBLE
        }

        calView.setOnDateChangeListener { calendarView, i, i2, i3 ->
            selectYear = i
            selectMonth = i2 + 1
            selectDay = i3
        }

        btnStart.setOnClickListener {
            chrono.base = SystemClock.elapsedRealtime()
            chrono.setTextColor(Color.RED)
            chrono.start()
        }
        btnEnd.setOnClickListener {
            chrono.stop()
            chrono.setTextColor(Color.BLUE)

            tvYear.text = Integer.toString(selectYear)
            tvMonth.text = selectMonth.toString()
            tvDay.text = selectDay.toString()

            tvHour.text = Integer.toString(tPicker.currentHour) //currentHour) //minSDK 23이상인 경우만 사용할 수 있음
            tvMinute.text = Integer.toString(tPicker.currentMinute) //currentMinute)
        }
    }
}