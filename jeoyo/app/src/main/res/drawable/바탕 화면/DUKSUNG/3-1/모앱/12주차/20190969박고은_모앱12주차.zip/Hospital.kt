package org.techtown.myopenhospital

data class Hospital(val yadmNm:String?, val sidoNm:String?, val phone_number:String?)